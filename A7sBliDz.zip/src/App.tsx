import { motion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";

type Currency = "EUR" | "USD" | "JPY" | "DZD";
type VehicleCondition = "new" | "used";
type VehicleType = "city" | "sedan" | "suv" | "hybrid" | "electric";
type ExchangeMode = "bank" | "parallel";
type Language = "ar" | "en";

type EstimateProfile = {
  engineCc: number;
  fuel: "gasoline" | "hybrid" | "electric";
  shippingEur: number;
  insuranceRate: number;
  label: string;
};

type Result = {
  cifDzd: number;
  customsDuty: number;
  tic: number;
  vat: number;
  fixedFees: number;
  subtotalTaxes: number;
  discount: number;
  netTaxes: number;
  finalTotal: number;
};

const currencyLabelsAr: Record<Currency, string> = {
  EUR: "يورو",
  USD: "دولار",
  JPY: "ين",
  DZD: "دينار جزائري",
};

const currencyLabelsEn: Record<Currency, string> = {
  EUR: "Euro",
  USD: "Dollar",
  JPY: "Yen",
  DZD: "Algerian Dinar",
};

const ratesToDzdDefault: Record<Currency, number> = {
  EUR: 155,
  USD: 133,
  JPY: 0.85,
  DZD: 1,
};

const ratesToDzdParallel: Record<Currency, number> = {
  EUR: 260,
  USD: 232,
  JPY: 1.5,
  DZD: 1,
};

const vehicleProfiles: Record<VehicleType, EstimateProfile> = {
  city: {
    engineCc: 1400,
    fuel: "gasoline",
    shippingEur: 950,
    insuranceRate: 0.017,
    label: "صغيرة",
  },
  sedan: {
    engineCc: 1800,
    fuel: "gasoline",
    shippingEur: 1200,
    insuranceRate: 0.018,
    label: "سيدان",
  },
  suv: {
    engineCc: 2400,
    fuel: "gasoline",
    shippingEur: 1650,
    insuranceRate: 0.019,
    label: "دفع رباعي",
  },
  hybrid: {
    engineCc: 1800,
    fuel: "hybrid",
    shippingEur: 1300,
    insuranceRate: 0.018,
    label: "هجين",
  },
  electric: {
    engineCc: 0,
    fuel: "electric",
    shippingEur: 1400,
    insuranceRate: 0.017,
    label: "كهربائية",
  },
};

const formatDzd = (value: number) =>
  new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 }).format(Math.max(0, Math.round(value)));

export default function App() {
  const [language, setLanguage] = useState<Language>("ar");
  const [carPriceInput, setCarPriceInput] = useState("");
  const [currency, setCurrency] = useState<Currency>("EUR");
  const [vehicleType, setVehicleType] = useState<VehicleType>("sedan");
  const [year, setYear] = useState(2025);
  const [condition, setCondition] = useState<VehicleCondition>("used");
  const [showRates, setShowRates] = useState(false);
  const [exchangeMode, setExchangeMode] = useState<ExchangeMode>("bank");
  const [ratesToDzd, setRatesToDzd] = useState(ratesToDzdDefault);

  const isArabic = language === "ar";
  const currencyLabels = isArabic ? currencyLabelsAr : currencyLabelsEn;
  const carPrice = Number(carPriceInput) || 0;
  const t = {
    brand: "A7sBli Dz",
    heroTitle: isArabic
      ? "احسب جمركة سيارتك في الجزائر خلال دقيقة واحدة"
      : "Calculate Your Algeria Car Customs Cost in One Minute",
    heroSub: isArabic
      ? "احسب بسرعة وبشكل واضح تكلفة السيارة مع الجمركة في مكان واحد."
      : "Quickly calculate the full car cost with customs in one place.",
    startNow: isArabic ? "ابدأ الحساب الآن" : "Start Now",
    how: isArabic ? "كيف يعمل" : "How It Works",
    formTitle: isArabic ? "املأ البيانات بطريقتك الجديدة" : "Enter Your Car Details",
    formSub: "",
    resultTitle: isArabic ? "النتيجة الفورية" : "Instant Result",
    resultSub: isArabic ? "الإجمالي المتوقع بالدينار الجزائري" : "Estimated total in DZD",
    detailTitle: "",
  };

  const profile = vehicleProfiles[vehicleType];
  const currentYear = new Date().getFullYear();
  const allowedYears = [2026, 2025, 2024];
  const age = Math.max(0, currentYear - year);

  const inputPriceDzd = carPrice * ratesToDzd[currency];
  const shippingDzd = profile.shippingEur * ratesToDzd.EUR;
  const insuranceDzd = inputPriceDzd * profile.insuranceRate;

  const customsRate = useMemo(() => {
    if (profile.fuel === "electric") return 15;
    return profile.engineCc <= 1800 ? 15 : 30;
  }, [profile.engineCc, profile.fuel]);

  const ticRate = useMemo(() => {
    if (profile.fuel === "electric") return 0;
    if (profile.engineCc <= 1800) return 0;
    if (profile.engineCc <= 2000) return 30;
    return 60;
  }, [profile.engineCc, profile.fuel]);

  const reductionRate = useMemo(() => {
    if (condition !== "used") return 0;
    if (profile.fuel === "electric") return 80;
    if (profile.fuel === "hybrid" || profile.fuel === "gasoline") return profile.engineCc <= 1800 ? 50 : 20;
    return 0;
  }, [condition, profile.engineCc, profile.fuel]);

  const result = useMemo<Result>(() => {
    const cifDzd = inputPriceDzd + shippingDzd + insuranceDzd;
    const customsDuty = cifDzd * (customsRate / 100);
    const tic = cifDzd * (ticRate / 100);
    const vat = (cifDzd + customsDuty + tic) * 0.19;
    const fixedFees = 45000;

    const subtotalTaxes = customsDuty + tic + vat + fixedFees;
    const discount = subtotalTaxes * (reductionRate / 100);
    const netTaxes = subtotalTaxes - discount;

    return {
      cifDzd,
      customsDuty,
      tic,
      vat,
      fixedFees,
      subtotalTaxes,
      discount,
      netTaxes,
      finalTotal: cifDzd + netTaxes,
    };
  }, [customsRate, inputPriceDzd, reductionRate, shippingDzd, ticRate, insuranceDzd]);

  const notes = useMemo(() => {
    const list: string[] = [];
    if (condition === "used" && age > 3) {
      list.push(
        isArabic
          ? "تنبيه: عمر السيارة يتجاوز 3 سنوات وقد لا تكون مؤهلة للاستيراد الفردي."
          : "Warning: Vehicle age is over 3 years and may not be eligible for personal import."
      );
    }
    if (condition === "used") {
      list.push(
        isArabic
          ? "تذكير: النظام يراعي قاعدة سيارة واحدة كل 3 سنوات للأفراد."
          : "Reminder: Individuals are typically limited to one imported used vehicle every 3 years."
      );
    }
    list.push(
      isArabic
        ? "النتيجة تقديرية وتحتاج مطابقة مع ملف الجمارك النهائي قبل الدفع."
        : "This is an estimate and should be verified with the final customs file before payment."
    );
    return list;
  }, [age, condition, isArabic]);

  useEffect(() => {
    setRatesToDzd(exchangeMode === "bank" ? ratesToDzdDefault : ratesToDzdParallel);
  }, [exchangeMode]);

  useEffect(() => {
    document.documentElement.lang = isArabic ? "ar" : "en";
    document.documentElement.dir = isArabic ? "rtl" : "ltr";
  }, [isArabic]);

  const carOnlyTotal = inputPriceDzd;
  const grandTotalWithCustoms = carOnlyTotal + result.netTaxes;

  return (
    <main dir={isArabic ? "rtl" : "ltr"} className="bg-slate-950 text-slate-100">
      <section
        className="relative min-h-screen overflow-hidden bg-cover bg-center"
        style={{ backgroundImage: "url('/images/algeria-customs-hero.jpg')" }}
      >
        <div className="fixed inset-x-0 top-0 z-50 mx-auto flex w-full max-w-6xl justify-end px-4 py-4 md:px-8">
          <div className="inline-flex rounded-xl border border-white/20 bg-slate-900/75 p-1 text-sm shadow-lg shadow-slate-950/30 backdrop-blur">
            <button
              type="button"
              onClick={() => setLanguage("ar")}
              className={`rounded-lg px-3 py-1.5 transition ${language === "ar" ? "bg-cyan-300 text-slate-950" : "text-slate-200"}`}
            >
              العربية
            </button>
            <button
              type="button"
              onClick={() => setLanguage("en")}
              className={`rounded-lg px-3 py-1.5 transition ${language === "en" ? "bg-cyan-300 text-slate-950" : "text-slate-200"}`}
            >
              English
            </button>
          </div>
        </div>
        <motion.div
          animate={{ x: [0, 30, -20, 0], y: [0, -24, 16, 0] }}
          transition={{ duration: 14, repeat: Infinity, ease: "easeInOut" }}
          className="absolute -right-14 top-28 h-44 w-44 rounded-full bg-cyan-300/20 blur-3xl"
        />
        <motion.div
          animate={{ x: [0, -20, 20, 0], y: [0, 18, -12, 0] }}
          transition={{ duration: 16, repeat: Infinity, ease: "easeInOut" }}
          className="absolute -left-10 bottom-24 h-40 w-40 rounded-full bg-indigo-300/20 blur-3xl"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950/70 via-slate-900/55 to-slate-950" />
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="relative z-10 mx-auto flex min-h-screen w-full max-w-6xl flex-col items-center justify-center px-4 text-center md:px-8"
        >
          <p className="text-3xl font-extrabold tracking-tight text-cyan-300 md:text-5xl">{t.brand}</p>
          <h1 className="mt-4 max-w-3xl text-4xl font-bold leading-tight text-white md:text-6xl">
            {t.heroTitle}
          </h1>
          <p className="mt-4 max-w-2xl text-lg text-slate-200">{t.heroSub}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href="#calculator"
              className="rounded-xl bg-cyan-400 px-6 py-3 font-semibold text-slate-950 transition hover:scale-[1.03] hover:bg-cyan-300"
            >
              {t.startNow}
            </a>
            <a
              href="#how"
              className="rounded-xl border border-white/30 bg-white/5 px-6 py-3 font-semibold text-white transition hover:bg-white/10"
            >
              {t.how}
            </a>
          </div>
        </motion.div>
      </section>

      <section id="calculator" className="relative mx-auto grid w-full max-w-6xl gap-8 px-4 py-12 md:px-8 md:py-16 lg:grid-cols-[1.1fr_0.9fr]">
        <motion.form
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6 }}
          className="space-y-6 rounded-3xl border border-white/10 bg-slate-900/60 p-5 backdrop-blur md:p-7"
        >
          <h2 className="text-2xl font-semibold text-white">{t.formTitle}</h2>

          <div className="space-y-2">
            <p className="text-sm text-slate-300">{isArabic ? "مصدر سعر الصرف" : "Exchange Rate Source"}</p>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setExchangeMode("bank")}
                className={`rounded-xl border py-2 transition ${
                  exchangeMode === "bank"
                    ? "border-cyan-300 bg-cyan-300/10 text-white"
                    : "border-white/15 bg-white/5 text-slate-300"
                }`}
              >
                {isArabic ? "سعر البنك" : "Bank Rate"}
              </button>
              <button
                type="button"
                onClick={() => setExchangeMode("parallel")}
                className={`rounded-xl border py-2 transition ${
                  exchangeMode === "parallel"
                    ? "border-cyan-300 bg-cyan-300/10 text-white"
                    : "border-white/15 bg-white/5 text-slate-300"
                }`}
              >
                {isArabic ? "سعر السوق الموازي" : "Parallel Market Rate"}
              </button>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <label className="space-y-2">
              <span className="text-sm text-slate-300">{isArabic ? "سعر السيارة" : "Car Price"}</span>
              <input
                type="number"
                value={carPriceInput}
                onChange={(e) => setCarPriceInput(e.target.value)}
                min={0}
                step={100}
                placeholder={isArabic ? "ادخل السعر" : "Enter price"}
                className="w-full rounded-xl border border-white/20 bg-slate-950/80 px-3 py-2 text-white outline-none transition focus:border-cyan-400"
              />
            </label>

            <SelectField
              label={isArabic ? "العملة" : "Currency"}
              value={currency}
              onChange={(value) => setCurrency(value as Currency)}
              options={[
                { value: "EUR", label: isArabic ? "يورو (EUR)" : "Euro (EUR)" },
                { value: "USD", label: isArabic ? "دولار (USD)" : "Dollar (USD)" },
                { value: "JPY", label: isArabic ? "ين (JPY)" : "Yen (JPY)" },
              ]}
            />
          </div>

          <SelectField
              label={isArabic ? "نوع السيارة" : "Car Type"}
            value={vehicleType}
            onChange={(value) => setVehicleType(value as VehicleType)}
              info={
                isArabic
                  ? "اختيار نوع السيارة يحدد تلقائيا سعة محرك مرجعية وتقدير شحن وتأمين، وبالتالي يؤثر على الرسوم."
                  : "Car type sets estimated engine size, shipping, and insurance, which affects taxes."
              }
            options={[
                { value: "city", label: isArabic ? "صغيرة" : "Compact" },
                { value: "sedan", label: isArabic ? "سيدان" : "Sedan" },
                { value: "suv", label: isArabic ? "دفع رباعي" : "SUV" },
                { value: "hybrid", label: isArabic ? "هجين" : "Hybrid" },
                { value: "electric", label: isArabic ? "كهربائية" : "Electric" },
            ]}
          />

          <div className="space-y-2">
            <p className="text-sm text-slate-300">{isArabic ? "سنة الصنع" : "Year"}</p>
            <div className="grid grid-cols-3 gap-3">
              {allowedYears.map((y) => (
                <button
                  key={y}
                  type="button"
                  onClick={() => setYear(y)}
                  className={`rounded-xl border py-2 text-sm transition ${
                    year === y
                      ? "border-cyan-300 bg-cyan-300/10 text-white"
                      : "border-white/15 bg-white/5 text-slate-300"
                  }`}
                >
                  {y}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <p className="text-sm text-slate-300">{isArabic ? "الحالة" : "Condition"}</p>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setCondition("used")}
                className={`rounded-xl border py-2 transition ${
                  condition === "used"
                    ? "border-cyan-300 bg-cyan-300/10 text-white"
                    : "border-white/15 bg-white/5 text-slate-300"
                }`}
              >
                {isArabic ? "مستعملة" : "Used"}
              </button>
              <button
                type="button"
                onClick={() => setCondition("new")}
                className={`rounded-xl border py-2 transition ${
                  condition === "new"
                    ? "border-cyan-300 bg-cyan-300/10 text-white"
                    : "border-white/15 bg-white/5 text-slate-300"
                }`}
              >
                {isArabic ? "جديدة" : "New"}
              </button>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setShowRates((prev) => !prev)}
            className="text-sm text-cyan-200 underline decoration-cyan-300/70 underline-offset-4"
          >
            {showRates
              ? isArabic
                ? "إخفاء تعديل الصرف"
                : "Hide rate editor"
              : isArabic
                ? "تعديل سعر الصرف يدويا"
                : "Edit exchange rates manually"}
          </button>

          {showRates && (
            <div className="grid gap-4 sm:grid-cols-3">
              <InputField
                label={isArabic ? "1 EUR بالدينار" : "1 EUR in DZD"}
                value={ratesToDzd.EUR}
                onChange={(v) => setRatesToDzd((prev) => ({ ...prev, EUR: v }))}
                min={1}
                step={0.01}
              />
              <InputField
                label={isArabic ? "1 USD بالدينار" : "1 USD in DZD"}
                value={ratesToDzd.USD}
                onChange={(v) => setRatesToDzd((prev) => ({ ...prev, USD: v }))}
                min={1}
                step={0.01}
              />
              <InputField
                label={isArabic ? "1 JPY بالدينار" : "1 JPY in DZD"}
                value={ratesToDzd.JPY}
                onChange={(v) => setRatesToDzd((prev) => ({ ...prev, JPY: v }))}
                min={0.01}
                step={0.001}
              />
            </div>
          )}

        </motion.form>

        <motion.section
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="sticky top-5 h-fit rounded-3xl border border-cyan-300/20 bg-cyan-400/10 p-5 md:p-7"
          whileHover={{ y: -3 }}
        >
          <p className="text-sm text-cyan-200">{t.resultTitle}</p>

          <motion.div
            key={Math.round(grandTotalWithCustoms)}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="mt-4 rounded-2xl border border-cyan-200/30 bg-slate-900/50 p-4"
          >
            <p className="text-xs text-slate-300">{isArabic ? "السعر الإجمالي للسيارة مع الجمركة" : "Full price with customs"}</p>
            <p className="mt-2 text-3xl font-bold text-cyan-200">{formatDzd(grandTotalWithCustoms)} دج</p>
          </motion.div>

          <div className="mt-6 space-y-3 border-t border-white/10 pt-5">
            <BreakdownRow
              label={isArabic ? "قيمة CIF" : "CIF Value"}
              value={result.cifDzd}
              info={
                isArabic
                  ? "قيمة السيارة بعد تحويل العملة مضافا لها الشحن والتأمين. وهي الأساس الذي تبنى عليه أغلب الرسوم."
                  : "Vehicle value after currency conversion plus shipping and insurance. This is the base for most taxes."
              }
            />
            <BreakdownRow
              label={isArabic ? `حقوق جمركية (${customsRate}%)` : `Customs Duty (${customsRate}%)`}
              value={result.customsDuty}
              info={
                isArabic
                  ? "رسم جمركي يطبق كنسبة من قيمة CIF حسب نوع السيارة وسعة المحرك التقديرية."
                  : "A customs tax applied as a percentage of CIF based on car type and estimated engine size."
              }
            />
            <BreakdownRow
              label={`TIC (${ticRate}%)`}
              value={result.tic}
              info={
                isArabic
                  ? "الضريبة الداخلية على الاستهلاك، وتظهر غالبا مع المحركات الكبيرة وقد تكون صفر لبعض الفئات."
                  : "Domestic consumption tax, usually affecting larger engines and can be zero for some categories."
              }
            />
            <BreakdownRow
              label="TVA (19%)"
              value={result.vat}
              info={
                isArabic
                  ? "ضريبة القيمة المضافة. يتم حسابها على مجموع CIF مع الحقوق والضرائب الأساسية."
                  : "Value-added tax calculated on CIF plus primary customs duties and taxes."
              }
            />
            <BreakdownRow
              label={isArabic ? "رسوم ثابتة" : "Fixed Fees"}
              value={result.fixedFees}
              info={
                isArabic
                  ? "تكاليف إدارية تقديرية مرتبطة بالملف والإجراءات، وقد تختلف قليلا حسب الميناء والملف."
                  : "Estimated administrative fees related to the customs process, with slight variation by port and case."
              }
            />
            <BreakdownRow
              label={isArabic ? `تخفيض (${reductionRate}%)` : `Discount (${reductionRate}%)`}
              value={-result.discount}
              info={
                isArabic
                  ? "تخفيض تقديري خاص ببعض حالات السيارات المستعملة (مثل الكهربائية والهجينة وبعض السعات)."
                  : "Estimated reduction for some used-vehicle categories (like electric, hybrid, and some engine sizes)."
              }
            />
            <div className="h-px bg-white/10" />
            <BreakdownRow
              label={isArabic ? "إجمالي الرسوم" : "Total Taxes"}
              value={result.netTaxes}
              strong
              info={
                isArabic
                  ? "هذا مجموع كل الرسوم بعد تطبيق التخفيض، ولا يشمل ثمن شراء السيارة نفسه."
                  : "Total duties and taxes after discount; this does not include the original vehicle purchase price."
              }
            />
            <BreakdownRow
              label={isArabic ? "ثمن السيارة بعد التحويل" : "Car price after conversion"}
              value={carOnlyTotal}
            />
            <BreakdownRow
              label={isArabic ? "الإجمالي: سيارة + جمركة" : "Total: car + customs"}
              value={grandTotalWithCustoms}
              strong
            />
          </div>

          <div className="mt-6 border-t border-white/10 pt-4 text-sm text-slate-200">
            {notes.map((note) => (
              <p key={note} className="mb-2">
                - {note}
              </p>
            ))}
          </div>

          <div id="how" className="mt-6 border-t border-white/10 pt-4 text-sm text-cyan-100">
            <p>
              {isArabic ? `سعر ${currencyLabels[currency]}:` : `${currencyLabels[currency]} rate:`}{" "}
              {ratesToDzd[currency].toFixed(currency === "JPY" ? 3 : 2)} DZD
            </p>
            <p>{isArabic ? "تقدير الشحن:" : "Estimated shipping:"} {Math.round(profile.shippingEur)} EUR</p>
            <p>{isArabic ? "تقدير التأمين:" : "Estimated insurance:"} {(profile.insuranceRate * 100).toFixed(1)}%</p>
          </div>
        </motion.section>
      </section>
    </main>
  );
}

type InputFieldProps = {
  label: string;
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
  step?: number;
};

function InputField({ label, value, onChange, min = 0, max, step = 1 }: InputFieldProps) {
  return (
    <label className="space-y-2">
      <span className="text-sm text-slate-300">{label}</span>
      <input
        type="number"
        className="w-full rounded-xl border border-white/20 bg-slate-950/80 px-3 py-2 text-white outline-none transition focus:border-cyan-400"
        value={Number.isFinite(value) ? value : 0}
        min={min}
        max={max}
        step={step}
        onChange={(e) => onChange(Number(e.target.value))}
      />
    </label>
  );
}

type SelectFieldProps = {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: Array<{ value: string; label: string }>;
  info?: string;
};

function SelectField({ label, value, onChange, options, info }: SelectFieldProps) {
  const [isOpen, setIsOpen] = useState(false);
  const isArabicLabel = /[\u0600-\u06FF]/.test(label);

  return (
    <label className="space-y-2">
      <span className="flex items-center gap-2 text-sm text-slate-300">
        {label}
        {info && (
          <button
            type="button"
            onClick={() => setIsOpen((prev) => !prev)}
            className="flex h-5 w-5 items-center justify-center rounded-full border border-cyan-200/60 text-xs font-bold text-cyan-100 transition hover:bg-cyan-300/20"
            aria-label={isArabicLabel ? `شرح ${label}` : `Info about ${label}`}
          >
            ؟
          </button>
        )}
      </span>
      <select
        className="w-full rounded-xl border border-white/20 bg-slate-950/80 px-3 py-2 text-white outline-none transition focus:border-cyan-400"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      {info && isOpen && (
        <div className="rounded-xl border border-cyan-200/30 bg-slate-900 p-3 text-xs leading-6 text-slate-200">
          {info}
        </div>
      )}
    </label>
  );
}

type BreakdownRowProps = {
  label: string;
  value: number;
  strong?: boolean;
  info?: string;
};

function BreakdownRow({ label, value, strong = false, info }: BreakdownRowProps) {
  const [isOpen, setIsOpen] = useState(false);
  const display = value < 0 ? `- ${formatDzd(Math.abs(value))}` : formatDzd(value);

  return (
    <div className="relative flex items-center justify-between gap-3 text-sm">
      <div className="flex items-center gap-2">
        <span className={strong ? "font-semibold text-white" : "text-slate-300"}>{label}</span>
        {info && (
          <button
            type="button"
            onClick={() => setIsOpen((prev) => !prev)}
            className="flex h-5 w-5 items-center justify-center rounded-full border border-cyan-200/60 text-xs font-bold text-cyan-100 transition hover:bg-cyan-300/20"
            aria-label={`شرح ${label}`}
          >
            ؟
          </button>
        )}
      </div>
      <span className={strong ? "font-semibold text-white" : "text-slate-100"}>{display} دج</span>

      {info && isOpen && (
        <div className="absolute right-0 top-7 z-20 w-72 rounded-xl border border-cyan-200/30 bg-slate-900 p-3 text-xs leading-6 text-slate-200 shadow-lg shadow-slate-950/40">
          {info}
        </div>
      )}
    </div>
  );
}